# Intelligent Image Retrieval System

A lightweight, interactive cross-modal image retrieval platform built on Shneiderman’s Five-Stage Search Framework. Powered by Python, Gradio, and the OpenAI CLIP model, this system seamlessly supports both semantic text-to-image queries and exemplary image-to-image similarity matching.

---

## Features

* **Text to Image (Text Search):** Input descriptive English text to retrieve semantically matching images from the local database.
* **Image to Image (Image Search):** Upload a query image to find the most visually and conceptually similar results in the repository.
* **Dynamic Refinement Sliders:** Real-time interactive sliders to adjust the maximum return count (Top-N) and the minimum similarity confidence threshold.
* **Interactive Gallery & Download:** View retrieved images in a high-resolution lightbox preview and download them locally with a single click.

---

## Environment Setup

Ensure you have Python 3.9+ and the `conda` package manager installed on your system.

```bash
# 1. Activate your target environment
conda activate lab2

# 2. Install all required dependencies
pip install sentence-transformers pillow numpy gradio torch

Quick Start
1. Prepare the Dataset
Create a folder named dataset in the root directory of this project and place your reference images (.jpg, .png, .jpeg, etc.) inside it.

2. Run the Application
Execute the main script in your terminal:

Bash
python app_image_search.py
3. Access the Web Interface
Open your web browser and navigate to the local hosting address printed in the console:

Plaintext
[http://127.0.0.1:7860](http://127.0.0.1:7860)
---

## Project Structure & Architecture

```text
.
├── dataset/                  # Local reference image database (user-provided)
│                             # -> System will AUTOMATICALLY scan and build vector index upon startup
├── app_image_search.py       # Main pipeline script (Gradio UI frontend + CLIP backend)
│                             # -> Model weights will AUTOMATICALLY download on the first run
└── README.md                 # Project documentation (This file)(This file)
License
This project is developed for educational purposes as part of the Human-Computer Interaction (HCI) Lab Assignment.