import os

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
# 【新增】强制让 Python 忽略系统代理，彻底解决本地/localhost自检导致的 502 报错
os.environ["NO_PROXY"] = "localhost,127.0.0.1,0.0.0.0"

import re
from PIL import Image
import torch
import numpy as np
import gradio as gr
from sentence_transformers import SentenceTransformer

# ==================== 后端逻辑：模型与向量检索 ====================
print("正在初始化作业系统后端...")
model = SentenceTransformer('clip-ViT-B-32')
DATASET_DIR = "./dataset"

image_features = []
image_paths = []

def build_image_index():
    global image_features, image_paths
    image_features = []
    image_paths = []
    if not os.path.exists(DATASET_DIR):
        os.makedirs(DATASET_DIR)
        return
    valid_extensions = ('.jpg', '.jpeg', '.png', '.bmp', '.webp')
    files = [os.path.join(DATASET_DIR, f) for f in os.listdir(DATASET_DIR) if f.lower().endswith(valid_extensions)]
    
    images = []
    for p in files:
        try:
            img = Image.open(p).convert("RGB")
            images.append(img)
            image_paths.append(p)
        except:
            continue
            
    if images:
        features = model.encode(images, batch_size=8, show_progress_bar=False)
        image_features = features / np.linalg.norm(features, axis=1, keepdims=True)
        print(f"成功为 {len(image_paths)} 张图片建立检索索引！")

# 首次构建索引
build_image_index()

# ==================== 核心搜索调度函数 ====================
def perform_search(search_type, text_query, image_query, top_n, score_threshold):
    """
    执行搜索并返回结果，完美契合 Review 阶段与 Refinement 阶段
    """
    if len(image_features) == 0:
        return "⚠️ 数据集为空，请检查 dataset 文件夹！", []
    
    # 1. Formulation 阶段：判断搜索类型并提取对应的查询向量
    if search_type == "以文搜图 (Text Search)":
        if not text_query:
            return "⚠️ 请输入搜索文本描述！", []
        query_feat = model.encode([text_query])
    else:
        if image_query is None:
            return "⚠️ 请上传用于搜索的图片！", []
        # image_query 是 numpy 数组，转为 PIL Image
        img = Image.fromarray(image_query.astype('uint8'), 'RGB')
        query_feat = model.encode([img])
        
    # 向量归一化
    query_feat = query_feat / np.linalg.norm(query_feat, axis=1, keepdims=True)
    
    # 2. 计算余弦相似度
    similarities = np.dot(image_features, query_feat.T).squeeze()
    if similarities.ndim == 0:
        similarities = np.array([similarities])
        
    # 3. 排序并根据 Refinement 参数过滤
    sorted_indices = np.argsort(similarities)[::-1]
    
    output_gallery = []
    for idx in sorted_indices:
        score = float(similarities[idx])
        # 根据用户调整的相似度阈值进行过滤 (Refinement)
        if score >= score_threshold:
            output_gallery.append((image_paths[idx], f"相似度: {score:.4f}"))
            
    # 截取用户要求的图片数量 (Refinement)
    output_gallery = output_gallery[:int(top_n)]
    
    # 4. Review of results 阶段：提供检索总体概述文本
    summary_text = f"💡 【结果审查】搜索完成！在库中检测到 {len(image_paths)} 张图片。根据您的过滤参数，共匹配到 {len(output_gallery)} 张符合条件的图片（已按相似度从高到低排序）。"
    
    return summary_text, output_gallery


# ==================== 前端界面：基于五阶段框架设计 ====================
with gr.Blocks(title="HCI Image Search System") as demo:
    gr.Markdown("# 🔍 智能图像检索系统 (Image Retrieval System)")
    gr.Markdown("### 本系统严格基于人机交互 “五阶段搜索框架 (Five-Stage Search Framework)” 设计实现")
    
    with gr.Row():
        # --- LEFT PANEL: 输入与参数调节 (Formulation & Refinement) ---
        with gr.Column(scale=1):
            gr.Markdown("### 🛠️ 1 & 4. 构建与优化阶段 (Formulation & Refinement)")
            
            search_mode = gr.Radio(
                choices=["以文搜图 (Text Search)", "以图搜图 (Image Search)"], 
                value="以文搜图 (Text Search)", 
                label="选择搜索模式 (Select Mode)"
            )
            
            # 动态显示文本框或图片上传框
            text_input = gr.Textbox(
                label="文本查询输入 (Text Query)", 
                placeholder="例如: a cute cat, a speeding car...", 
                visible=True
            )
            image_input = gr.Image(
                label="图片查询输入 (Image Query)", 
                visible=False
            )
            
            # 模式切换联动
            def toggle_inputs(mode):
                if mode == "以文搜图 (Text Search)":
                    return gr.update(visible=True), gr.update(visible=False)
                else:
                    return gr.update(visible=False), gr.update(visible=True)
            search_mode.change(toggle_inputs, inputs=search_mode, outputs=[text_input, image_input])
            
            gr.Markdown("---")
            gr.Markdown("*可在下方调整控制参数以优化检索结果 (Refinement)*")
            top_n_slider = gr.Slider(minimum=1, maximum=10, value=5, step=1, label="最大返回图片数量 (Top-N)")
            threshold_slider = gr.Slider(minimum=0.0, maximum=1.0, value=0.1, step=0.05, label="相似度准入阈值 (Threshold)")
            
            # --- 2. Initiation 阶段：明确的启动按钮 ---
            gr.Markdown("### 🚀 2. 动作启动阶段 (Initiation)")
            search_btn = gr.Button("🔍 开始检索 (Search Now)", variant="primary")

        # --- RIGHT PANEL: 结果展示与后续动作 (Review & Use) ---
        with gr.Column(scale=2):
            gr.Markdown("### 📊 3. 结果审查阶段 (Review of results)")
            # 结果总体概述框
            status_output = gr.Markdown("*等待用户发起搜索操作...*")
            
            # 结果画廊展示（自带预览和查看）
            result_gallery = gr.Gallery(
                label="检索结果画廊 (按相似度从高到低排序)", 
                columns=2, 
                rows=2, 
                object_fit="contain", 
                height="auto"
            )
            
            gr.Markdown("---")
            # --- 5. Use 阶段：允许后续使用动作 ---
            gr.Markdown("### 💾 5. 结果使用阶段 (Use)")
            gr.Markdown("✨ *提示：点击上方检索出的任意一张图片可放大预览，点击图片右上角的下载图标即可直接保存到本地。*")

    # 点击按钮触发后端搜索逻辑
    search_btn.click(
        fn=perform_search,
        inputs=[search_mode, text_input, image_input, top_n_slider, threshold_slider],
        outputs=[status_output, result_gallery]
    )

# 启动网页端服务器
if __name__ == "__main__":
    # 【修改】加入 share=True 以开启外网公网穿透链接
    print("正在启动系统并生成公网共享链接...")
    demo.launch(server_name="0.0.0.0", share=False, debug=True, prevent_thread_lock=True)